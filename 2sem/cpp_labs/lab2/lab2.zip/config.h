#define ARR_LENGTH 1'000'000
#define MAX_N 30'000
#define MIN_N 100
#define STEP 1500
#define SEED 42