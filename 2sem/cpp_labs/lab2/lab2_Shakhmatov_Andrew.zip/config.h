#define ARR_LENGTH 10'000'000
#define MAX_N 20'000
#define MIN_N 100
#define STEP 1000
#define SEED 42
